def dividef(a, b):
    """Retorna a divisão de dois números reais."""
    if b == 0:
        raise ValueError('Não é possível dividir por zero.')
    return a / b


def teste_dividef():
    assert dividef(6, 3) == 2
    assert dividef(5, 2) == 2.5
    try:
        dividef(1, 0)
        assert False, 'Era esperado erro ao dividir por zero.'
    except ValueError:
        pass


if __name__ == '__main__':
    teste_dividef()
    print('Testes de divide.py passaram com sucesso!')
